Dendograms
---------------------
This is cluster representaion showing which variables behave alike and 
the ones that dont.

Much similar to the clustering result except in a different representaion 
easy to interprete.

The clusters with the same colours have similar behaviour and can be grouped into one.
While those which different colours can be grouped into different clusters.

What makes dendograms special is the ability to further create sub clusters, forming what we call
'Hierarchy'. Hence, the name Hierarchical clustering. Its clusters the features according to
the 254+ feature vectors in descending order(i.e from top to bottom.)