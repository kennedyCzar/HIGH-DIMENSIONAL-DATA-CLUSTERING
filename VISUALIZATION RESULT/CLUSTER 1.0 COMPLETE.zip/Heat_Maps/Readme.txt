Heat Map
---------------

The heat map shows the correlation existing between the feature vectors.
The features with think orange color means they are very correlated and
those with light orange colors or close to white means little or no correlation.

Whereas the features having blue intersection means they are negatively correlated.

Because you are the person who understands what the abbreviations is, you can make meaning
out of this.

The meaning and clusters however further shows variables with similar behaviour and
those without.