Scatter
----------------------
Scatter plot representing the distribution of the dataset in 2D space.

Barplot is simply a barchart representation of the data set.