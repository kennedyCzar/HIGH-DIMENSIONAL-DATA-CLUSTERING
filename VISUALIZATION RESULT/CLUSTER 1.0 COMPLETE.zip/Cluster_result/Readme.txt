---------------------------
--- Cluster Results
-----------------------------
This is the final result of the clustering.
1. The figure ending with _cluster: is the final clustering result of the different sheets
 extracted from the workbook.

	Each sheets is capable of producing different configuration of clustering after 
	applying the clustering algorithm.

	The graph shows a detailed representation of the feature vectors with respect
	to the Device name.

2. In addition to this is have added a graph showing how the data is clustered(where k represents
the numbers of clusters).

	As the algorithm is optimised to produce different cluster result by altering k between 2- 5.
	The best k value is shown to be 4 in most cases. This is not surprising as the data maybe gotten 
	using data mining architecture.

3. Lastly, the last diagram shows a machine learning approach used to get the optimum k cluster value.
   In most cases, the optimum k-value is 4, which is again no surprise.